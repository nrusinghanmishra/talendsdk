package com.citi.talend.components.service;

import org.talend.sdk.component.api.service.Service;

@Service
public class CitiBusinessRuleService {

    // you can put logic here you can reuse in components

}